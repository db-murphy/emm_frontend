var oBigMask = $("#bigMask");
var numMaskWidth = $(window).width();
var numMaskHeight = $(window).height();
oBigMask.css({width:numMaskWidth,height:numMaskHeight});