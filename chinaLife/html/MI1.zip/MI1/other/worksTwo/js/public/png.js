// JavaScript Document
EvPNG.fix('#text_list,a');